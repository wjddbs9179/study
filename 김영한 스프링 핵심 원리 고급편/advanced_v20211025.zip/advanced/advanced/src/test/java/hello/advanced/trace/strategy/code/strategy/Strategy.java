package hello.advanced.trace.strategy.code.strategy;

public interface Strategy {
    void call();
}
