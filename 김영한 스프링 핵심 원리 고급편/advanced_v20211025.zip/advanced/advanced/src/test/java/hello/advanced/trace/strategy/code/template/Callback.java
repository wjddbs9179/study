package hello.advanced.trace.strategy.code.template;

public interface Callback {
    void call();
}
