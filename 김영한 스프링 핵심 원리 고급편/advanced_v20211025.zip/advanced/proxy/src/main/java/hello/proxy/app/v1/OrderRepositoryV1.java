package hello.proxy.app.v1;

public interface OrderRepositoryV1 {
    void save(String itemId);
}
