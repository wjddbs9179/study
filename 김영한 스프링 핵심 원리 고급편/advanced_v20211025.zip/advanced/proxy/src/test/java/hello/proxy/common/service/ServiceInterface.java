package hello.proxy.common.service;

public interface ServiceInterface {
    void save();

    void find();
}
