package hello.proxy.jdkdynamic.code;

public interface AInterface {
    String call();
}
