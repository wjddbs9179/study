package hello.proxy.jdkdynamic.code;

public interface BInterface {
    String call();
}
