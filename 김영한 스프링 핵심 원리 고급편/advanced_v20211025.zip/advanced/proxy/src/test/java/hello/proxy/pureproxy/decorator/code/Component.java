package hello.proxy.pureproxy.decorator.code;

public interface Component {
    String operation();
}
