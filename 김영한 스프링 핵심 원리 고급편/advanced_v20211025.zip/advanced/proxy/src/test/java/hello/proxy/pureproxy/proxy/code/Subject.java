package hello.proxy.pureproxy.proxy.code;

public interface Subject {
    String operation();
}
